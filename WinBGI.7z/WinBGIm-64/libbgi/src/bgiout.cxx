#include <stringstream>
class BGIout : virtual std::basic_ostringstream
{
public:

};

BGIout bgiout;

